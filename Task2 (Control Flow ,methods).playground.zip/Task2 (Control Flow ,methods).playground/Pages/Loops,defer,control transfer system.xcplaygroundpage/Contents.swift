//FOR IN LOOP

 

//DEFER STATEMENTS

 func exampledefer(){
    print("This")
    defer {
        print("defer")
    }
    print("is example of ")
}
exampledefer()
print()



func Lifoexample(){
    defer {
        print("i am third")
    }
    defer {
        print("i am second")
    }
    print("I am first")
}
Lifoexample()


//WHILE LOOP
 let finalsquare=25
var board=[Int](repeating:0,count:finalsquare+1)
board[03] = +08
board[06] = +11
board[09] = +09
board[10] = +02
board[14] = -10
board[19] = -11
board[22] = -02
board[24] = -08
var square=0
var diceRoll=0
while square<finalsquare{
    diceRoll+=1
    if diceRoll==7 {diceRoll=1}
    square+=diceRoll
    if square<board.count{
        square+=board[square]
    }
    
}
print("Game over")

print()
print()

//Repeat while

 var count=1
repeat{print("Count is \(count)")
    count+=1
    
}while count<=5
 

print()
print()

 let temperatureInCelsius = -5
var freezeWarning: String?

if temperatureInCelsius <= 0 {
    freezeWarning = "It's below freezing. Watch for ice!"
} else {
    freezeWarning = nil
}
print(freezeWarning ?? "No warning")

//SWITCH STATEMENT

 let alphabet:Character = "b"
switch alphabet{
case "a":print("This is 1st alphabet")
case "b":print("This is second alphabet")
case "z":print("this is last character")
default:print("this is some another character")
}

//INTERVAL MATCHING
  let approximateCount=62
let countedthings="moons orbitting saturn"
let naturalCount: String
switch approximateCount{
case 0: naturalCount = "No"
case 1..<5:naturalCount = "a few"
case 5..<12:naturalCount = "Several "
case 12..<100:naturalCount = " dozens of "
default:naturalCount="many"
}
print("There are \(naturalCount) \(countedthings).")


//VALUE BINDINGS

 let anotherPoint=(2,2)
switch anotherPoint{
case(let x,0):print("on x axis \(x)")
case (0,let y):print("on y axis \(y)")
case (let(x,y)):print("on x we have \(x) and on y we have \(y)")
    
}
print()
print()
 
let someCharacter: Character = "e"
switch someCharacter {
case "a", "e", "i", "o", "u":
    print("\(someCharacter) is a vowel")
case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m",
    "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
    print("\(someCharacter) is a consonant")
default:
    print("\(someCharacter) isn't a vowel or a consonant")
}
print()
print()
print()
//CONTROL TRANFER SYSTEM
    //CONTINUE
 
let puzzleInput="Great minds thinks alike "
var puzzleOutput=""
let characterToRemove:[Character] = ["a","e","i","o","u"]
for character in puzzleInput{
    if characterToRemove.contains(character){
        continue
    }
    puzzleOutput.append(character)
    
}
print(puzzleOutput)
 
print()
print()
print()
//FALLTHROUGH
 
let number=2
switch number{
case 2:
    print("matched case 2")
    fallthrough
case 4:
    print("matched")
case 3:
    print("Matched case 3")

default:print("Default Case")
}
 
print()
print()
print()
 
func greetAgain(person: String) -> String {
    return "Hello again, " + person + "!"
}
print(greetAgain(person: "ARyan"))
// Prints "Hello again, Anna!"
 
print()
print()
print()
print()
//MIN MAX FUNCTION

 func minmax(array : [Int])->(min:Int,max:Int){
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count]{
        if value<currentMin{
            currentMin = value}
        else if value>currentMax{
            currentMax = value
        }
        
    }
    return (currentMin,currentMax)
}
let array = [3,2,4,6,5,3]
let result = minmax(array:array)
print("min value is \(result.min) and max value is \(result.max)")
 


//FUNCTION ARGUMENT LABEL AND PARAMETER NAME
print()
print()
 
func calculateInterest(principle p:Int , time t:Int, rate r:Int){
    let res=(p*t*r)/100
    print(res)
}
calculateInterest(principle:1000,time:12,rate:2)
 print()
print()
//Variadic Parameter
 
func arithmeticmean(_ numbers:Double...)->Double{
    var total:Double=0
    for num in numbers{
        total += num
    
    }
    return total/Double(numbers.count)
    
}
print(arithmeticmean(2,3,4,5,6))
print(arithmeticmean(8,3.23,5.43,8))
 
print()
print()
print()
//INOUT
func swapnums(_ a:inout Int, _ b:inout Int){
    let temp=a
    a=b
    b=temp
    
}
var x=10
var y=20
print("Original value of x= \(x) and y is \(y)")
swapnums(&x,&y)
print("New values of x=\(x) and y is \(y)")
print()
print()
print()

func choosestep(backward:Bool)->(Int)->Int{
    func stepforward(input: Int)->Int{return input+1}
    func stepbackward(input:Int)->Int{return input-1}
    return backward ?  stepbackward : stepforward
}
var currentvalue = 4
let movenear = choosestep(backward:currentvalue>0)
while currentvalue != 0{
    print("\(currentvalue)...")
    currentvalue = movenear(currentvalue)
}
print("zero")

print()
print()
print()

func factorial(_ number: Int) -> Int {
    func multiply(_ n: Int) -> Int {
        if n <= 1 {  // Handles both n == 1 and n == 0 cases
            return 1
        } else {
            return n * multiply(n - 1)
        }
    }
    return multiply(number)
}

let results = factorial(4)
print("Factorial is: \(results)")

enum Beveragesss: Int{
    case one=1
    case two=2
}
var type = Beveragesss.two
switch type{
case .two:
    print("This is 2")
case .one:
    print("This is 3")
}
print()
print()

enum QLMembers:CaseIterable{
    case male
    case female
}
var typeQL = QLMembers.allCases.count
print(typeQL)
let types = QLMembers.allCases.map({"\($0)"}).joined(separator:",")
print(types)




