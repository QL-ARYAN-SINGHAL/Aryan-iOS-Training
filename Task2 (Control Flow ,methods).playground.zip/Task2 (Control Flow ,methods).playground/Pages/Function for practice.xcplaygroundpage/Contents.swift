//Check if plaindrome or not
let greeting="Aryan Singhal"
print(
    greeting[greeting.startIndex]
    
    
)
print(greeting[greeting.index(before:greeting.endIndex)]
)

print(greeting.count)
let index = greeting.index(greeting.startIndex, offsetBy: 9)
print(greeting[index])

let find = greeting.index(greeting.endIndex , offsetBy: -4)
print(greeting[find])


let string = "hi i am aryan singhal "
let indexs = string.index(string.startIndex , offsetBy : 3 )
print("\(string[indexs] )" , terminator: " ")



var welcome = " hi you are welcome here"
print(welcome.insert("!" , at: welcome.endIndex))
print(welcome)
print(welcome.insert(contentsOf: " aryan", at: welcome.index(before: welcome.endIndex)))
print(welcome)



var word = "hello there"
var range = word.index(word.startIndex, offsetBy: 0 ) ..< word.index(word.startIndex, offsetBy: 5)
word.removeSubrange(range)
print(word)
print()
print()
print()

let greetings = "Hello, world!"
let indexes = greetings.firstIndex(of: ",") ?? greetings.endIndex
let beginning = greetings[..<indexes]
// beginning is "Hello"


// Convert the result to a String for long-term storage.




let sentence = "hi this is a sentence"
let sub = sentence.firstIndex(of: "f" ) ?? sentence.endIndex
let total = sentence[..<sub]
let newString = String(total)
print(newString)


let this = "hi this"
let that = "hi this"
if this == that {
    print("they are same")
}
else{
    print("they are not same")
}



//PALINDROME CHECK

let string1 = " radar "
let string2 = String(string1.reversed())
if string1 == string2{
    print("Yes they are palindrome")
}
else{
    print("they ar enot palindrome")
}

//to add words after sentence







 //PREFIX AND SUFFIX

let password="1234"
print(
    password.hasPrefix("2"),
    password.hasSuffix("43")
)

var name="Tom&Harry"
name.dropFirst()
name.dropFirst(3)
name.dropLast()
name.dropLast(5)
print(name)
name.removeFirst()
name.removeLast()
name.removeFirst(4)
print(name)
name.insert(contentsOf: " apple a day keep doctor away", at: name.endIndex)
print(name)
name.removeFirst(3)


let hellochar : [Character] = ["h" , "e" , "l" , "l" , "o"]
String(hellochar)
let numbersystem:[Int] = [1,2,3,4,5]
String(numbersystem.description)


var stars="***XYZ***"
if let xyzrange=stars.firstRange(of: "XYZ"){
    stars.replaceSubrange(xyzrange, with: "ABC")
}
print(stars)


//finding max element of array
func array(_ a:[Int]) ->Int{
    var currentmax = a[0]
    for num in 1...a.count{
        if currentmax < num{
            currentmax=num
        }
        
    }
    return currentmax
}
let a = [3,2,6,1,4,5]
print(array(a))

//Find missing number in arrray
func missingNumber(array:[Int])->[Int]{
    let array=array.sorted()
    let firstIndex = array.first ?? 0
    let lastIndex = array.last ?? 0
    let result = Array(firstIndex...lastIndex)
    let missing = result.filter{!array.contains($0)}

    return missing
    
}
print(missingNumber(array:[13,11,19,20])
)



print()
print()
let array=[1,2,5,66,7,32]
var arr=Array(array.sorted())
var i=arr.index(arr.endIndex, offsetBy: -3)
print(arr[i])

//find if number present in array
func find(_ a :[Int] , _ b :Int)->Bool {
    if a.contains(b) {
        return true
    }
    else{
        return false
    }
}
print(
    find([1,2,3,4] , 6)
)
print(150*50000)

