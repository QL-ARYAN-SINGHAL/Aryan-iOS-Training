class Persons{
    var residence : Residences?
}
class Residences{
    var noOfRooms = 1
}
let john = Persons()
// var firstPerson = john.residence!.noOfRooms
if let roomcount =  john.residence?.noOfRooms{
    print("\(roomcount) has rooms")
    
}
else{
    print("No rooms founds")
  
}

var newResident=Residences()
print(newResident.noOfRooms)
newResident.noOfRooms = 8
print(newResident.noOfRooms)

//CLASSAS FOR OPTIONAL CHAINING

class Person{
    var residence: Residence?
}
class Residence{
    var rooms:[Room]=[]
    var numberofrooms:Int{
        return rooms.count
    }
    subscript(i:Int)->Room{
        get{
            return rooms[i]
        }
        set{
            rooms[i] = newValue
        }
    }
    func printNumberOfRooms() {
            print("The number of rooms is \(numberofrooms)")
        }
        var address: Address?
    
}
class Room{
    var name:String
    init(name:String){
        self.name = name
    }
}
class Address{
    var buildingName:String?
    var buildingNumber:String?
    var street:String?
    func buildingIdentifier()->String?{
        if let buildingNumber = buildingNumber,let street=street{
            return "\(buildingNumber) , \(street)"
        }else if buildingName != nil{
            return buildingName
        }else{
            return nil
        }
    }}
//Accessing property through optional chaining
var gzb = Address()
gzb.buildingName="ABC"
gzb.buildingNumber="12345"
gzb.street="Noida"


let aryan = Person()
if let roomscount = aryan.residence?.numberofrooms
{
    print("John's residence has \(roomscount) room(s).")
} else {
    print("Unable to retrieve the number of rooms.")
}
aryan.residence?.numberofrooms

func printNumberOfRooms(){
    print("No os rooms here are ")
}
if  aryan.residence?.printNumberOfRooms() != nil{
    print("No of rooms are")
}
else{
    print("No of rooms are nil")
}


if let firstRoomName = aryan.residence?[0].name{
    print("first room name is \(firstRoomName)")
}
else{
    print("No rooms")
}

aryan.residence?[0] = Room(name:"Bathroom")


//Accesing subscripts through option chaining

var testscored = ["Aryan" : [1,2,3,4] ,  "Dhawal" : [6,7,8,9]]
testscored["Aryan"]?[0] = 1
testscored["Aryan"]?[3] = 5
print(testscored)
testscored["Dhawal"]?[0] += 1
print(testscored)

