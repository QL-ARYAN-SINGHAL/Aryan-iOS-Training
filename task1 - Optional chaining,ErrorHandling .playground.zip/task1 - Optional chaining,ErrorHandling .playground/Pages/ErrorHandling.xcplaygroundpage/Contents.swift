// Error handling in Swift involves functions or initializers that can throw errors.
// When a function can throw, add the `throws` keyword after the parameter list.
// If the function returns a value, write the return type after `->` along with `throws`.

enum VendingMachineError: Error {
    case invalidSelection
    case insufficientFunds(coinsRequired: Int)
    case outOfStock
}

// Example: Throwing an error
// throw VendingMachineError.insufficientFunds(coinsRequired: 5)

struct Item {
    var price: Int
    var count: Int
}

class VendingMachine {
    var coinsDeposited = 100
    var inventory: [String: Item] = [
        "Candy": Item(price: 10, count: 5),
        "Chips": Item(price: 30, count: 10),
        "Chocolate": Item(price: 15, count: 20)
    ]
    
    func vend(itemNamed name: String) throws {
        guard let item = inventory[name] else {
            throw VendingMachineError.invalidSelection
        }
        guard item.count > 0 else {
            throw VendingMachineError.outOfStock
        }
        guard item.price <= coinsDeposited else {
            throw VendingMachineError.insufficientFunds(coinsRequired: item.price - coinsDeposited)
        }
        
        // Deduct the price from deposited coins
        coinsDeposited -= item.price
        
        // Update the inventory
        var newItem = item
        newItem.count -= 1
        inventory[name] = newItem
        
        print("Dispensing \(name)")
    }
}

let favoriteSnacks: [String: String] = [
    "Alice": "Chips",
    "Bob": "Licorice",
    "Eve": "Pretzels"
]

func buyFavoriteSnack(person: String, vendingMachine: VendingMachine) throws {
    let snackName = favoriteSnacks[person] ?? "Candy"
    try vendingMachine.vend(itemNamed: snackName)
}

struct PurchasedSnack {
    let name: String
    
    // Throwing initializer using try to vend the item
    init(name: String, vendingMachine: VendingMachine) throws {
        try vendingMachine.vend(itemNamed: name)
        self.name = name
    }
}

// Demonstrating error handling with do-catch
var vendingMachine = VendingMachine()
vendingMachine.coinsDeposited = 8  // Adjusted coin value for demonstration

do {
    try buyFavoriteSnack(person: "Alice", vendingMachine: vendingMachine)
    print("Success")
} catch VendingMachineError.invalidSelection {
    print("Invalid selection")
} catch VendingMachineError.outOfStock {
    print("Item out of stock")
} catch VendingMachineError.insufficientFunds(let coinsRequired) {
    print("Insufficient funds. Please insert an additional \(coinsRequired) coins.")
} catch {
    print("Unexpected error: \(error).")
}

// Converting error to optional
func someThrowingFunction() throws -> Int {
    return 2
}

let x = try? someThrowingFunction()


var y: Int?
do {
    y = try someThrowingFunction()
} catch {
    y = nil
}

print("x:", x as Any)
print("y:", y as Any)

//CLEANUP ACTION - DEFER

func processFile(filename:String) throws{
    if exists("Screenshot 2025-02-21 at 9.55.06 AM.png"){
        let file = open("Screenshot 2025-02-21 at 9.55.06 AM.png")
    }
    defer{
        close(file)       //defer statement helps in cleanup like even if there is a n issue with file then also it will close the file at the end
    }
    while let line = readLine(){
        
    }
}
 

