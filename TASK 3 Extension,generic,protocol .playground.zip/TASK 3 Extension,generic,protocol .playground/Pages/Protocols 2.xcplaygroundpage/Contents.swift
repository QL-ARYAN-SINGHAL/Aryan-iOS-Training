//COnforming to protocol--- we conform to protocol using typecasting that is we use 1. (is) to check if true else false
//2. (as?) to cast safely otherwise nil value . 3. (as!) to force downcasting otherwise run time error

protocol HasArea{
    var area:Double {get}
}
class Circle:HasArea{
    let pi=3.14
    let radius:Double
    var area:Double{return pi*radius*radius}
    init(radius:Double){
        self.radius = radius
    }
}                                     //Both country and circle conforms to Hasarea protocol
class Country:HasArea{
    var area :Double
    init(area:Double){
        self.area = area
    }
}
class Animal{                         //Animal does not confrom to the protocol
    var legs:Int
    init(legs:Int){
        self.legs = legs
    }
}
let objects : [AnyObject] = [Circle(radius:4.0),Country(area:1000000),Animal(legs:4)]
for object in objects{
    if let objectWithArea = object as? HasArea{  //Here typescript as? checks if objects is of HasArea type if yes then                                            if let conition is true ,if false then else condition is printed
        print("Area is \(objectWithArea.area)")
    }
    else{
        print("Something does not have area")
    }
}
import Foundation

//optional protocol requirements
//@objc for classes and optional keyword to make it optional.

@objc protocol CounterDataSource{
    @objc optional func increment(forCount count:Int)->Int
    @objc optional var fixedIncrement:Int {get}
}
class Counter{
    var count = 0
    var dataSource:CounterDataSource?
    func increment(){
        if let amount = dataSource?.increment?(forCount: count) { //Double optional chaining is done here that if
            //" dataSource?" should return true if not then false and then "increment?" should return true else false
            count += amount
        } else if let amount = dataSource?.fixedIncrement {
            count += amount
        }
        
    }
}
class ThreeSource :NSObject,CounterDataSource{
    
    let fixedIncrement = 3
    
}
var counter = Counter()
counter.dataSource = ThreeSource()
for _ in 1...4 {
    counter.increment()
    print(counter.count)
}
