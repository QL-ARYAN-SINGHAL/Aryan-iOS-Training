import Foundation
//Protocols are the blueprint of methods or properties that suits particular task
protocol SomeProtocol{
    var mustBeSettable : Int {get set}  //Get set are the property reequirements which have get property and set property
    static var someType :Int {get}  //In protocol we always make the type porperty as the static
}

protocol FullName{
    var fullyNamed : String{get}
    
}
struct Person : FullName{
    var fullyNamed : String
}
let aryan = Person(fullyNamed: "Aryan Singhal")
print(aryan)

//eg 2
class Starship: FullName {
    var prefix: String?
    var name: String
    init(name: String, prefix: String? = nil) {
        self.name = name
        self.prefix = prefix
    }
    var fullyNamed: String {
        return (prefix != nil ? prefix! + " " : "") + name
    }
}
var ncc1701 = Starship(name: "Enterprise", prefix: "USS")

//Methods Protocols
protocol SomeType{
    static func someTypefunc()
}

//eg
protocol RandomNumberGenerator{
    func random()->Double
}
class LinearCongruentialGenerator:RandomNumberGenerator{
    var lastRandom = 42.0
    let m = 139968.0
    let a = 3877.0
    let c = 29573.0
     
    func random()->Double{
        lastRandom = ((lastRandom*a+c)).truncatingRemainder(dividingBy: m)
        return lastRandom/m
    }
    
}
let generator = LinearCongruentialGenerator()
print("Here's a random number: \(generator.random())")
print("And another one: \(generator.random())")

//MUTATING FUNCTIONS IN PROTOCOLS
protocol Togglable{
    mutating func toggle()
}
enum onOffSwitch: Togglable{
    case on,off
    mutating func toggle(){
        switch self{
        case .on : self = .off
        case .off : self = .on
        }
        }
    }

var swicthlights = onOffSwitch.off
print(swicthlights.toggle())

//CLASS AND INHERITENCE WITH PROTOCOL
protocol sometype{
    init()
}
class Animal{
    init(){}
}
class Dog:Animal,sometype{
    required override init(){
        
    }
}
//DElegation and protocols

// MARK: - Dice Game & Delegate

protocol DiceGameDelegate: AnyObject {
    func gameDidStart(_ game: DiceGame)
    func game(_ game: DiceGame, didEndRound round: Int, winner: Int?)
    func gameDidEnd(_ game: DiceGame)
}

class DiceGame {
    var sides: Int
    weak var delegate: DiceGameDelegate?
    
    init(sides: Int) {
        self.sides = sides
    }
    
    func roll() -> Int {
        // Use Swift's random generation for the dice roll
        return Int(Double.random(in: 0..<1) * Double(sides)) + 1
    }
    
    func play(rounds: Int) {
        delegate?.gameDidStart(self)
        
        for round in 1...rounds {
            let player1 = roll()
            let player2 = roll()
            
            if player1 == player2 {
                delegate?.game(self, didEndRound: round, winner: nil)
            } else if player1 > player2 {
                delegate?.game(self, didEndRound: round, winner: 1)
            } else {
                delegate?.game(self, didEndRound: round, winner: 2)
            }
        }
        
        delegate?.gameDidEnd(self)
    }
}

class DiceGameTracker: DiceGameDelegate {
    var playerScore1 = 0
    var playerScore2 = 0
    
    func gameDidStart(_ game: DiceGame) {
        print("Started a new game")
        playerScore1 = 0
        playerScore2 = 0
    }
    
    func game(_ game: DiceGame, didEndRound round: Int, winner: Int?) {
        switch winner {
        case 1:
            playerScore1 += 1
            print("Player 1 won round \(round)")
        case 2:
            playerScore2 += 1
            print("Player 2 won round \(round)")
        default:
            print("The round was a draw")
        }
    }
    
    func gameDidEnd(_ game: DiceGame) {
        if playerScore1 == playerScore2 {
            print("The game ended in a draw.")
        } else if playerScore1 > playerScore2 {
            print("Player 1 won!")
        } else {
            print("Player 2 won!")
        }
    }
}

// Instantiate and play the dice game
let tracker = DiceGameTracker()
let game = DiceGame(sides: 6)
game.delegate = tracker
game.play(rounds: 3)


// MARK: - Protocols with Extensions

protocol TextRepresentable {
    var textualDescription: String { get }
}

// A simple linear congruential generator, similar to the one in Swift's sample code
// Define a Dice type that uses a generator
struct Dice {
    let sides: Int
    let generator: LinearCongruentialGenerator
    
    func roll() -> Int {
        return Int(generator.random() * Double(sides)) + 1
    }
}

extension Dice: TextRepresentable {
    var textualDescription: String {
        return "A \(sides)-sided die"
    }
}

let d12 = Dice(sides: 12, generator: LinearCongruentialGenerator())
print(d12.textualDescription)
let d6 = Dice(sides:10 , generator : LinearCongruentialGenerator())
print(d6.textualDescription)

// Define a simple SnakesAndLadders game
class SnakesAndLadders {
    let finalSquare: Int = 100
    // Additional game implementation would go here
}

extension SnakesAndLadders: TextRepresentable {
    var textualDescription: String {
        return "A game of Snakes and Ladders with \(finalSquare) squares"
    }
}

let snakesAndLadders = SnakesAndLadders()
print(snakesAndLadders.textualDescription)

//COnditionally confirming to protocol
extension Array : TextRepresentable where Element: TextRepresentable{
    var textualDescription: String{
        let itemsAsText = self.map{$0.textualDescription}
        return "[" + itemsAsText.joined(separator: ", ") + "]"
    }
}
let myDice = [d6,d12 ]
print(myDice.textualDescription)

//PRotocol adoption with extensions
//we can adopt a protocol using empty extension
struct Hamster{
    var name :String
    var textualDescription : String{
        return "i am a hamster named \(name)"
    }
}
extension Hamster : TextRepresentable{}
let simonhasmter = Hamster(name : "Dhawal")
let sometextRepresentable :TextRepresentable = simonhasmter
print(simonhasmter.textualDescription)

//ADOPTING USING SYNTHESIZED PROTOCOLS
//IN PROTOCOL WE HAE EQUATABLE AND HASHABLE BY DEFAULT. EQUALTABLE IS ONLUY FOR ENUM AND STRUCTURES


//EG OF EQUATABLE P[ROTOCOL]
struct Vector3D:Equatable{
    var x = 0.0 , y=0.0 , z=0.0
}
let firstVector = Vector3D(x : 1.1 , y: 2.1 , z: 3.1 )

let secondVector = Vector3D(x : 1.1 , y: 2.1 , z: 3.1 )

if firstVector == secondVector{
    print("Both vector are equal")
}
else{
    print("Not equal")
}

//COMPARABLE Protocol ( >=,>,=< )
enum SkillLevel:Comparable{
    case beginnner
    case intermediate
    case exper(stars:Int)
}
let myskill = [SkillLevel.beginnner , SkillLevel.intermediate , SkillLevel.exper(stars: 5) ,SkillLevel.exper(stars: 4)]
for skills in myskill.sorted(){
    print(skills)
}

//Inheritience in protocols -- in protocol we can inherit similarly like class but with more options tio inherit
protocol PrettyText : TextRepresentable{
   var prettyDescription : String {get}
}

//PROTOCOL COMPISITION - IN PROTOCOLS WE CAN COMBINE TWO OR MORE PROTOCOLS INTO A SINGLE REQUIREMENT using " & "
protocol Name{
    var name : String{get}
}
protocol Age{
    var age: Int {get}
    
}
struct Persons:Name,Age{
    var name:String
    var age: Int
    
}
func wishedhappyBirthday(to celeberator:Name & Age ){
    print("happy birthday to \(celeberator.name) who is of age \(celeberator.age)")
}
let happybirthday = Persons(name: "aryan" , age: 22)
wishedhappyBirthday(to: happybirthday)

//another example
class Location{
    var latitude:Double
    var longitude:Double
    init(latitude:Double,longitude:Double){
        self.latitude = latitude
        self.longitude = longitude
    }
}
class City:Location,Name{
    var name : String
    init(name:String,latitude:Double,longitude:Double){
        self.name = name
        super.init(latitude:latitude,longitude:longitude)
    }
}
func beginConcert(in location:Location & Name){
    print("Hello ! \(location.name)")
}
let seattle = City(name: "Seattle", latitude: 47.6, longitude: -122.3)
beginConcert(in: seattle)
