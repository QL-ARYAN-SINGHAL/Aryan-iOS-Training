// MARK: - Swap Two Values Function (Generics)
func swapTwoValues<T>(_ a: inout T, _ b: inout T) {
    let temp = a
    a = b
    b = temp
}

var first = 3
var second = 5
swapTwoValues(&first, &second)
print("First value: \(first)")
print("Second value: \(second)")

var newFirst = "Aryan"
var newSecond = "Singhal"
swapTwoValues(&newFirst, &newSecond)
print(newFirst, newSecond)


// MARK: - Generic Stack Definition
struct Stack<Element> {
    var items: [Element] = []
    
    mutating func push(_ item: Element) {
        items.append(item)
    }
    
    mutating func pop() {
        if !items.isEmpty {
            items.removeLast()
        }
    }
}

// MARK: - Extension: Top Item
extension Stack {
    var topItem: Element? {
        return items.last
    }
}

// MARK: - Conforming Stack to AContainer (when Element is Equatable)
protocol AContainer {
    associatedtype Item: Equatable
    mutating func append(_ item: Item)
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}

extension Stack: AContainer where Element: Equatable {
    typealias Item = Element
    
    var count: Int {
        return items.count
    }
    
    subscript(i: Int) -> Element {
        precondition(i >= 0 && i < items.count, "Index out of range")
        return items[i]
    }
    
    mutating func append(_ item: Element) {
        self.push(item)
    }
}

// MARK: - Find Index Function
func findIndex(of valueToFind: String, in array: [String]) -> Int? {
    return array.firstIndex(of: valueToFind)
}

let strings = ["cat", "dog", "llama", "parakeet", "terrapin"]
if let foundIndex = findIndex(of: "llama", in: strings) {
    print("The index of llama is \(foundIndex)")
}


// MARK: - InStack: A non-generic Stack for Ints Conforming to AContainer
struct InStack: AContainer {
    var items: [Int] = []
    
    mutating func push(_ item: Int) {
        items.append(item)
    }
    
    mutating func pop() {
        if !items.isEmpty {
            items.removeLast()
        }
    }
    
    // Conformance to AContainer:
    typealias Item = Int
    
    var count: Int {
        return items.count
    }
    
    subscript(i: Int) -> Int {
        precondition(i >= 0 && i < items.count, "Index out of range")
        return items[i]
    }
    
    mutating func append(_ item: Int) {
        self.push(item)
    }
}

// MARK: - Conforming Stack to SuffixableContainer (when Element is Equatable)
protocol SuffixableContainer: AContainer {
    associatedtype Suffix: SuffixableContainer where Suffix.Item == Item
    func suffix(_ size: Int) -> Suffix
}

extension Stack: SuffixableContainer where Element: Equatable {
    func suffix(_ size: Int) -> Stack {
        let validSize = min(size, count)  // Prevents out-of-range issues
        var result = Stack()
        for index in (count - validSize)..<count {
            result.append(self[index])
        }
        return result
    }
}

// MARK: - Conforming InStack to SuffixableContainer
extension InStack: SuffixableContainer {
    func suffix(_ size: Int) -> Stack<Int> {
        let validSize = min(size, count)
        var result = Stack<Int>()
        for index in (count - validSize)..<count {
            result.append(self[index])
        }
        return result
    }
}

// MARK: - Testing Suffix Functionality
var stackOfInts = Stack<Int>()
stackOfInts.append(10)
stackOfInts.append(20)
stackOfInts.append(30)
let suffix = stackOfInts.suffix(2)  // suffix contains 20 and 30
print("Suffix items: \(suffix.items)")


// MARK: - Generic Where Clause Function
func allItemsMatch<C1: AContainer, C2: AContainer>(
    _ someContainer: C1,
    _ anotherContainer: C2
) -> Bool where C1.Item == C2.Item, C1.Item: Equatable {
    
    if someContainer.count != anotherContainer.count {
        return false
    }
    
    for i in 0..<someContainer.count {
        if someContainer[i] != anotherContainer[i] {
            return false
        }
    }
    
    return true
}

var stackOfStrings = Stack<String>()
stackOfStrings.push("Hi")
stackOfStrings.push("Aryan")
stackOfStrings.push("How are you")
var arrayOfStrings = ["Hi", "Aryan", "How are you"]
if allItemsMatch(stackOfStrings, arrayOfStrings) {
    print("Exact match")
} else {
    print("Nothing matched")
}

// MARK: - Generic Subscript Extension
extension AContainer {
    subscript<Indices: Sequence>(indices: Indices) -> [Item]
            where Indices.Iterator.Element == Int {
        var result: [Item] = []
        for index in indices {
            if index >= 0 && index < count { // Prevents out-of-bounds errors
                result.append(self[index])
            }
        }
        return result
    }
}
