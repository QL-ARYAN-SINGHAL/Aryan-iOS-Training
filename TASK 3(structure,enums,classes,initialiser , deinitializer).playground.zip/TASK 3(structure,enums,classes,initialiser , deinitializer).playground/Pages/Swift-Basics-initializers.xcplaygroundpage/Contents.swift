struct Farenheit{
    var temp:Double
    init() {
         temp=32
    }
}
let f = Farenheit()
print(f.temp)

print()
print()

struct Temperature{
    var temp:Double
    init(fromFarenhiet Farenhiet:Double) {
        temp = (Farenhiet - 32.0) / 1.8
        
    }
    init(fromCelsius Celsius:Double ) {
        temp = Celsius - 273.5
    }
}

let tempincelcuis = Temperature(fromFarenhiet : 212)
print(tempincelcuis)

let tempinfarenhiet = Temperature(fromCelsius:293.5)
print(tempinfarenhiet)



print()
print()
struct Color{
    var red :Double
    var blue : Double
    var green : Double
    init(red:Double,blue:Double,green:Double){
        self.red = red
        self.blue = blue
        self.green = green
        
    }
    init(white:Double){
        red = white
        green = white
        blue = white
    }
}
let Firstcolor = Color(red : 1.5 , blue : 2.0 , green : 2.5 )
let secondcolor = Color(white: 0)
print(Firstcolor)
print(secondcolor)

print()

struct Location{
    var currlocation:String
    init(currlocation:String){
        self.currlocation = currlocation
    }
    func locationupdate(){
        print(currlocation)
    }
}
var mylocation = Location(currlocation: "Delhi")
print(mylocation)
mylocation.locationupdate()
mylocation.currlocation="Uttar pradesh"
print(mylocation)
mylocation.locationupdate()
print()
print()
class SurveyQuestion{
    let text:String
    var response:String?
    init(text:String){
        self.text=text
        
    }
    func ask(){
        print("the text was : "+"\(text)")
    }
}
var mytext = SurveyQuestion(text: "This is my first text")
print(mytext.text)
mytext.ask()
mytext.response = "Is this the first text"

print()
print()
struct Size{
    var width = 0.0 , height = 0.0
}
var newwidth = Size(width:2.0)
print(newwidth)
newwidth.height = 3.5
print(newwidth.width , newwidth.height)


print()
print("Delegation")
print()

struct Sizes{
    var width = 0.0
    var height = 0.0
}
struct Point{
    var x = 0.0
    var y = 0.0
}
struct Rect{
    var origin = Point()
    var size = Sizes()
    init(){}
    init(origin:Point , size:Sizes){
        self.origin=origin
        self.size=size
    }
    init(center:Point,size:Sizes){
        let originX = center.x - (size.width/2)
        let originY = center.y - (size.height/2)
        self.init(origin:Point(x:originX,y:originY) , size: size)
    }
    
}
let basicRect = Rect()
let originRect = Rect(origin: Point(x: 2.0, y: 2.0),
    size: Sizes(width: 5.0, height: 5.0))
let centerRect = Rect(center: Point(x: 4.0, y: 4.0),
    size: Sizes(width: 3.0, height: 3.0))

print()
print()
class Person {
    var name: String
    var age :Int
    init(name:String , age:Int){
        self.name = name
        self.age = age
    }
    convenience init(name: String){
        self.init(name:name, age: 12)
    }
    convenience init(age: Int){
        self.init(name:"Zeeshan", age:age )
    }
}

let firstperson = Person(name:"Aryan" , age:20)
print(firstperson.name,firstperson.age)
let secondperson = Person(name: "Dhawal")
print(secondperson.name,secondperson.age)
let thirdperson = Person(age:21)
print(thirdperson.name,thirdperson.age)
