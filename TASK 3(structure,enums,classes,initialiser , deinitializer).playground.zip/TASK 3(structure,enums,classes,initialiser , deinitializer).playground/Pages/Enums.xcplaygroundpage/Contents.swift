

enum Day{
   case monday,tueday,wednesday,thursday,friday,saturday,sunday
}
var today: Day = .thursday
switch today{
case .monday : print("Today is monday")
case .friday:print("End of week")
default: print("another day")
}

print()

print()

print()

enum direction{
   case north ,south ,east ,west
}
var mydirxn : direction = .west
switch mydirxn{
case .north : print("I am at north")
case .south : print("I am at south")
case .east: print("I am at east")
case .west : print("i am west")

   
}


print()
print()
print()

enum Beverage: CaseIterable {
   case coffee, tea, juice
}
let numberOfChoices = Beverage.allCases.count
print("\(numberOfChoices) beverages available")
// Prints "3 beverages available"
for type in Beverage.allCases{
   print("\(type) is avaiable")
   if type == .tea{
       print("Good tea")
   }
   else{
      print("Bad tea")
   }
}

print()
print()
print()

enum Beverages{
   case tea(flavour:String)
   case coffee(size:String)
   case juice(fruit:String)
}

let mydrink = Beverages.coffee(size:"Large")
let yourdrink = Beverages.tea(flavour:"Hazzlenut")
switch yourdrink{
case .coffee(let size): print("Your cofffee is of \(size) size")
case .tea(let flavour): print("Your tea is of \(flavour) flavour")
case .juice(let fruit) : print(" Your juice is of \(fruit) fruit")
}

//BANKING SYSTEM IN ASSOCIATED ENUM '

enum BankingTransaction{
   case deposit(amount:Double)
   case withdrawl(amount:Double)
   case transfer (amount:Double , toAccount: String)
   case checkBalance(accountNumber:String)
}

func processTransaction(_ transaction : BankingTransaction){
   switch transaction{
   case .deposit(let amount): print("Amount deposited is \(amount)")
   case .withdrawl(let amount): print("AMount withdrawl is \(amount)")
   case .transfer(let amount , let toAccount): print("Amount transfered is \(amount) in account number \(toAccount)")
   case .checkBalance(let accountNumber): print("balance in account \(accountNumber) is checked")
   
   }
}
let t1=BankingTransaction.deposit(amount:500)

let t2=BankingTransaction.withdrawl(amount:200)

let t3=BankingTransaction.transfer(amount:1000,toAccount:"'123456'")

let t4=BankingTransaction.checkBalance(accountNumber:"'345671234'"  )

processTransaction(t1)
processTransaction(t2)
processTransaction(t3)
processTransaction(t4)

print()
print()
print()

//SOLVING AN EXPRESSION USING RECURIVE ENUM

enum arithmatic{
   case number(Int)
  indirect case addition(arithmatic,arithmatic)
  indirect case multiply(arithmatic,arithmatic)
}
//expression (5+4)*2
let five = arithmatic.number(5)
let four = arithmatic.number(4)
let sum = arithmatic.addition(five,four)
let product = arithmatic.multiply(sum,arithmatic.number(2))

func solve(_ expression : arithmatic)->Int{
   switch expression{
   case let.number(value) : return value
   case let.addition(left,right): return solve(left) + solve(right)
   case let.multiply(left,right): return solve(left)*solve(right)
       
   }
}
print(solve(product))

print()
print()
print()

func fibonacci(_ n: Int)->Int{
   
       if n<=1{
           return n
       }
       else {
           return fibonacci(n-1) + fibonacci(n-2)
       }
   
}
let result=fibonacci(6)
print(result)

print()
print()
print()


//Factorial

func factorial(_ number:Int)->Int{
   func multiply(_ n:Int)->Int{
       if n<=1{
           return 1
       }
       else{
           return n*multiply(n-1)
       }
   }
   return multiply(number)
   
}

let answer=factorial(7)
print(answer)

print()
print()
print()

//SUM OF DIGITS
func sum(_ number:Int)->Int{
   var num=number
   var result=0
   while num>0{
       result += num % 10
       num /= 10
       
   }
   return result
}
let solution=sum(15)
print(solution)

//Check if number is perfect

func perfect(_ number:Int)->Bool{
   var sum=0
   for i in 1..<number{
       if number % i==0{
           sum+=i
       }
   }
   return sum == number
}
print(perfect(6))
print(perfect(25))
print(perfect(28))
                   
print()

print()

print()
//GCD OF 2 NUMBERS
func gcd(_ a : Int , _ b : Int)->Int{
   var x = a
   var y = b
   while y != 0{
       let temp = y
       y = x % y
       x = temp
   }
   return x
}
print(gcd(56,80))


print()
print()
print()

//
//PRIME NUMBER
func prime( _ number: Int)->[Int]{
   var num = number
   var factors = [Int]()
   var divisor = 2
   while num >= divisor{
       if num % divisor == 0{
           factors.append(divisor)
           num /= divisor
       }
       else{
           divisor += 1
       }
       
       
   }
   return factors
}
print(prime(10))


//
enum Days : CaseIterable{
   case monday,wedneday
   
}
var newday = Days.allCases.count
for counts in Days.allCases{
   print("\(counts)")
}

if Days.allCases.count == 1 {
    print("this is good enum")
}
else{
   print("\(Days.allCases.count)")
}



print()
print()
print()
let shopping: [String] = ["Juice" , "APPLE"]
for (index,value) in shopping.enumerated(){
   print("At \(index) we have \(value)")
}
print()
print()
print()
print()
print()
print()
var letters = Set <Character>()
print("letter ius of type Set<Character> with \(letters.count) items")
print()
print()
print()
print()
print()
print()

let set1 : Set = ["aryan" , "dhawal" , "Saurav"]
let set2 : Set = [ "dhawal" , "vikram" , "Isha"]
print(
   set1.isSubset(of: set2),
   set1.isSuperset(of: set2),
   set1.isDisjoint(with: set2)
)
print()
print()
print()
print()
print()
print()
func example( _ a : Int){
  print("this is first line")
   defer {
       print("this should be my third line")
   }
   print("this is second line")
}
print(example(4))
print()
print()
print()
print()
print()
print()

let numbers: Int = 3
switch numbers{
case 1,2,3:
   print("3 is present in 1st case")
case 4,5,6:
   print("3 is present in 2nd case")
default : print("nothing")
}
print()
print()
print()
print()
print()
print()

func minmax(_ array :[Int])->(min: Int , max: Int){
   var currentmin = array[0]
   var currentmax = array[0]
   for num in array[1..<array.count]{
       if num < currentmin{
           currentmin = num
       }
       else if num > currentmax
           {
               currentmax = num
           }
       }
   return (currentmin,currentmax)
   }
   

let array = [3,4,5,1,2]
let resultSS = minmax(array)
print("Min value is \(resultSS.min) and max value is \(resultSS.max)")
