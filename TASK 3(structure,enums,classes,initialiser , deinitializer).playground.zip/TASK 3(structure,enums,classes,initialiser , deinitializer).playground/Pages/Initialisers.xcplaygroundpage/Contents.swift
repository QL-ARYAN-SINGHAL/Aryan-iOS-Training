
struct NucleurRocket{
    var meters:Double
    var feet:Double
    init (meters:Double , feet:Double ){
        self.meters=meters
        self.feet=feet
    }
    init(gallons:Double , liters : Double) {
        let Newgallon = gallons * 3.48
        let Newliters = liters / 3.48
        self.init(meters:Newgallon , feet:Newliters)
    }
    
}
var FirstRocket = NucleurRocket(meters:20 , feet: 150)
print(FirstRocket.feet)
var SecondRocket = NucleurRocket(gallons: 150 , liters : 20)
print(
    SecondRocket.meters
)


print()
print()
print("OVERIDING CLASS")

print()
class Vehicle{
var numberofwheels=0
    var description:String{
        return "\(numberofwheels) number of wheels are there"
        
    }
    
}

class Bicycle:Vehicle{
    override init(){
        super.init()
        numberofwheels = 2
    }
}
class Car:Vehicle{
    override init(){
        super.init()
        numberofwheels=4
    }
}

class HoverBoard:Vehicle{
    var color:String
    init(color:String) {
        self.color=color
    }
    override var description:String{
        return "\(super.description) wheels are there adn color is \(color)"
    }
}
let vehicle = Vehicle()
print(vehicle.description)
let bicycle = Bicycle()
print(bicycle.description)
let car = Car()
print(car.description)
let hoverboard=HoverBoard(color:"Red")
print(hoverboard.description)


print()


class SuperClass{
    
    func fullName(){
        print("This is Superclass")
        
    }
    func sirName(){
 print("Sirname is not there")
    }
}
class SubClass:SuperClass{
     override func fullName(){
        print( "This is SubClass")
        
    }
    override func sirName(){
        print("Sirname is there")
    }
}
let myname = SuperClass()
myname.fullName()
let othername = SubClass()
othername.fullName()
othername.sirName()
myname.sirName()

print()
print()

class Food{
    var name:String
    init(name:String) {
        self.name=name    //Designated initlaiser
    }
    convenience init() {
        self.init(name : "[unnamed]")  //convinience initaliser
    }
}
let namedMeat = Food(name:"Salad")
print(namedMeat.name)

class RecipeIngredient : Food{
    var quantity:Int
    init(name:String , quantity : Int) {
        self.quantity = quantity
        super.init(name:name)
    }
    override convenience init(name:String){
        self.init(name : name , quantity : 1)
    }
}
let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)

class ShoppingListItem: RecipeIngredient {
    var purchased = false
    var description: String {
        var output = "\(quantity) x \(name)"      //automatic initialiser because default value is provided and no initaliser is created for this class so it directly overrides propertyies of parent clas, its DI and CI
        output += purchased ? " ✔" : " ✘"
        return output
    }
}
var newbreakfast = [ShoppingListItem(),ShoppingListItem(name:"Bacon") , ShoppingListItem(name : "Eggs" , quantity : 6), ]
newbreakfast[0].name = "Orange juice"
newbreakfast[0].purchased = true
for item in newbreakfast{
    print(item.description)
}


print()
print()
let wholeNumber : Double = 12345.0
let pi :Double = 3.1456
if let exactNumber = Int(exactly:wholeNumber){
    print(exactNumber)
}
let valuechanged = Int(exactly:pi)
if valuechanged == nil {
    print("Pi value is nill")
}


//Failable intialiser
struct Animal{
    var species:String
    init?(species:String){
        if species.isEmpty{
            return nil
        }
        self.species=species
    }
}
let creature = Animal(species:"elephant")

if let giraffe = creature{print(print("An animal was initialized with a species of \(giraffe.species)"))}
let anonymouscreature = Animal(species:"")
if anonymouscreature == nil{
    print("No animal was found")
}
print()
print()

enum TemperatureUnit{
    case celsius,kelvin,farenheit
    init?(symbol:Character){
        switch symbol {
        case "K":self = .kelvin
        case "C":self = .celsius
        case "F":self = .farenheit
        default:return nil
            
        }
    }
}
let fahrenheitUnit = TemperatureUnit(symbol: "F")
if fahrenheitUnit != nil {
    print("This is a defined temperature unit, so initialization succeeded.")
}



let unknownUnit = TemperatureUnit(symbol: "X")
if unknownUnit == nil {
    print("This isn't a defined temperature unit, so initialization failed.")
}


//If a subclass has intialisation overide of parent class and if FI of subclass fails then whole code fails
print()
print()
class Product{
    var name:String
    init?(name:String){
        if name.isEmpty{
            return nil}
        self.name=name
    }
}
class CartItems:Product{
    var quantity:Int
    init?(name:String,quantity:Int){
        if quantity<1{return nil}
        self.quantity=quantity
        super.init(name:name)
    }
}

if let socksPair = CartItems(name:"Socks" ,quantity:2){
    print("Items : \(socksPair.name) and quantity is \(socksPair.quantity)")
}else{
print("Nill")}
if let balloons = CartItems(name:"",quantity:0){
    print("Items : \(balloons.name) and quantity is \(balloons.quantity)")}
else{
print("Notjing")}

//CHESS BOARD
struct Chessboard{
    let boardcolor:[Bool] = {
        var isBlack = false
        var tempBoard : [Bool] = []
        for i in 1...8{
            for j in 1...8{
                tempBoard.append(isBlack)
                isBlack = !isBlack
            }
            isBlack = !isBlack
        }
        return tempBoard
    }()
    
    func squareIsBlackAt(row:Int , column:Int)->Bool{
        return boardcolor[(row * 8) + column]
    }}
let board = Chessboard()
print(board.squareIsBlackAt(row: 0, column: 1))
// Prints "true"
print(board.squareIsBlackAt(row: 7, column: 7))


//DE INITIALIZERS

class Bank{
    static var coinsInBank = 10000
    static func distribute(coins numberofcoinsrequested :Int)->Int{
        let numberOfCoinsToVend = min(coinsInBank , numberofcoinsrequested)
        coinsInBank -= numberOfCoinsToVend
        return numberOfCoinsToVend
        
    }
    static func receive(coins: Int) {
            coinsInBank += coins
        }
    static func recieve(coins:Int){
        coinsInBank+=coins
    }
}
class Player{
    var coinsinPurse:Int
    init(coins:Int){
        coinsinPurse = Bank.distribute(coins: coins)
        
    }
    func win(coins:Int){
        coinsinPurse = Bank.distribute(coins: coins)
    }
    deinit {
            Bank.receive(coins: coinsinPurse)
        }
}
