struct Person{
    var name = "Aryan"
    var age = 18
}
class Department{
    var hr = Person()
    var developer = "ios"
}
var Firstperson = Person()
var TypesDepartments = Department()

print("\(Firstperson.name), is of age = \(Firstperson.age)")

print("\(TypesDepartments.hr), is of department = \(TypesDepartments.developer)")

TypesDepartments.hr.age=26
TypesDepartments.hr.name="Himanshu sir"

print("\(TypesDepartments.hr), is of department = \(TypesDepartments.developer)")

var SecondPerson = Person(name : "Abhishekh" , age : 28)
print("\(Firstperson) , \(SecondPerson)")


struct Animal{
    var dog:String
    var cat:String
}
let firstanimal = Animal(dog:"Bruno" , cat:"Meuu")
var newanimal = firstanimal
newanimal.dog = "King"
print(firstanimal)
print(newanimal)




print()
print()
struct Counter{
    var count = 0
    mutating func increment(){
        count+=1
    }
}
var startCounter = Counter()
startCounter.increment()
print(startCounter.count)

print()
print()
enum Direction{
    case north,south,east,west
    mutating func ToDirection(){
        self = .east
    }
}
var currdirection = Direction.north
var latestdirection = currdirection
currdirection.ToDirection()
print(latestdirection)
print(currdirection)

print()
print()

class VideoMode {
    
    var interlaced = false
    var frameRate = 0.0
    var name="Aryan"
}

var firstvideo = VideoMode()
firstvideo.interlaced = true
firstvideo.frameRate = 1
firstvideo.name = "Oppo"
print(firstvideo.name)
var secondvideo = firstvideo
secondvideo.name = "Apple"
print("\(secondvideo.name)")
print(firstvideo.name)
if firstvideo===secondvideo{
    print("yes they have identical")
}

print()
print()

struct Books{
    var name:String
    var author:String
    var totalbooks = 0
    
    var pages:Int?
    mutating func changebooks(){
        if name=="Physics"{
            print("This is not physics class")
            }
        }
        
    }
        
    


var firstbook = Books(name: "Maths" , author: "Arihant")
firstbook.name = "Swift-Learning"
firstbook.author = "Apple Documentation"
firstbook.pages = 32
print("INFORMATION OF THIS BOOK IS \(firstbook)")
var secondbook = firstbook.name
secondbook = "Physics"
print(secondbook)
firstbook.changebooks()
print(firstbook.name)

if firstbook.name=="Swift-Learning"{
    firstbook.name="Physics"
    firstbook.author="Hansraj"
    print(firstbook)
}
else{
    print("No swift learning present")
    
    
}
print(
    firstbook.totalbooks
)

firstbook.changebooks()


print()
print()

enum Connection: Int{
    case noInternet = 1001
        case serverNotFound = 404
        case unauthorized = 401
        case internalServerError = 500
}
var error = Connection.serverNotFound
if error == Connection.serverNotFound{
    print("Your server is \(Connection.serverNotFound.rawValue)")
}
var seconderror = Connection.unauthorized.rawValue
if seconderror == 401{
    print("You are unauthorized as per the \(seconderror)")
}



print()

enum Cab{
    case rapido ( bike: String)
    case ola (Car: String)
    case uber (Shuttle : String)
   
}
enum Driver:String{
    case name="Rakesh"
    
    
}
var firstuser = Cab.ola(Car:"UP161944")
var seconduser = Cab.rapido(bike: "UP141115")

print(firstuser)
firstuser = .ola(Car: "DL142666")
print(firstuser)



var firstdriver = Driver.name.rawValue
print(firstdriver)

if firstdriver == "Rakesh"{
    
    var thirddriver = Cab.rapido(bike: "HR267167")
    print(firstdriver,thirddriver)
    
}
else {
    firstdriver = "Dhawal"
    var thirddriver = Cab.rapido(bike: "HR267167")
    print(firstdriver , thirddriver)
}

print()
print()

struct Mobile {
    var name: String
    var brand:String
    
    mutating func count(){
        if !name.isEmpty{
            for char in name{
                print(char)
            }}
        
    }
}
var firstmobile = Mobile(name : "Iphone 14" , brand : "Apple" )
var secondmobile =  Mobile(name: "M35", brand: "Samsung")
secondmobile.name = "M40"
print(firstmobile,secondmobile)
print()
var thirdmobile = firstmobile
thirdmobile.name = "Iphone XR"
var fourthmobile = secondmobile
fourthmobile.brand = "Redmi"
var array = [firstmobile,secondmobile,thirdmobile,fourthmobile]
for mob in array{
    print(mob)
}

secondmobile.count()


print()
print()

