struct Banking{
    var withdrawl:Int
    var checkBalance:Int
    var deposit:Int
    
    mutating func currBalance(){
        checkBalance = deposit-withdrawl
        if checkBalance<0{
            print("Account cant be in negative")
            
        }
        else if checkBalance>0{
            print("Your account has balance of \(checkBalance)")
        }
        else{
            print("Your account balance is 0")
        }
        
        
    }
    mutating func amountDeposit(){
        checkBalance+=deposit
        print("Your updated balance is of amount \(checkBalance) after deposit of \(deposit)")
    }
    mutating func amountWithdrawl(){
        checkBalance-=withdrawl
        print("Your updated balance is of amount \(checkBalance) after withdrawl of \(withdrawl)")
    }
    
}

var firstUser = Banking(withdrawl:500,checkBalance:0 ,deposit:1200)
print(firstUser)

firstUser.currBalance()
firstUser.withdrawl=200
firstUser.amountWithdrawl()
firstUser.deposit=300
firstUser.amountDeposit()
