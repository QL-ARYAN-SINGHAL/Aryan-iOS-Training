
//1. To represent a value that may be missing
//2. async/await
//3. let

//4
func factorial(_ a :Int)->Int{
    if a<=1{
        return a
    }
    return a*factorial(a-1)
}
var number = factorial(5)
print(number)
print("\n")
//5.
class Person{
    var name:String
    var age:Int
init(name:String , age:Int){
    self.name = name
    self.age = age
}
func introduction(){
    print("Hi my name is \(name) and my age is \(age)")
}
}
var firstPerson = Person(name: "Aryan" , age : 21 )

firstPerson.introduction()

//6.
//let and var containers are used for storing the values . if we want to store a value that is immutable and cannot change we would use LET , if we want to store a mutable value we would use VAR

//------->//EG of let

/*let age = 29
age = age+1 //This shows error
 print(age)      */

//------> //eg of var

var numbers = 13
numbers = numbers+1
print(numbers)

//7.
//Value types are those which keeps unique copy of data.Changing the value would not change the original data.Structure,Enums are of value types
//Reference types are those which refer to the original data only.Changing the value would change the original data too.Classes and Actor follow Refercne types.

struct Car{
    var name:String
    var age:Int
    init(name:String,age:Int){
        self.name=name
        self.age=age
    }

}
var firstCar = Car(name:"Maruti" , age: 12)
print(firstCar.name)
var secondCar = firstCar
secondCar.name = "Skoda"
print(secondCar.name)    //here it shows that secondCar name would not change the firstperson car name  and would create a new instance
print(firstCar.name)


class Bike{
    var name:String
    var age:Int
    init(name:String,age:Int){
        self.name=name
        self.age=age
    }
}
var firstBike = Bike(name:"Royal Enfield" , age: 6)
var secondBike = firstBike
print(secondBike.name)
firstBike.name = "Jawa" //This shows original data is also changed because its  refernce type
print(secondBike.name)
print(firstBike.name)

//8.
/*Swift handle memory management using ARC- Automatic reference cycling. Swift deallocates all containers and other objects when not in use so that memory is free and resources are available for other to use
In ARC we have strong referencing cycle that is a strong reference is created among two classes which keep each other alive.To prevent that cycling we have 2 terms- weak and unowned
Weak are used when rltnship is for small time
unowned are used when rltnship is for equal amount of time
eg.*/

class Owner{
let nameowner:String
var owns:Vehicle?
init(nameowner:String){
    self.nameowner=nameowner
}
deinit{print("deinitialised the Owner named \(nameowner)")}
}

class Vehicle{
    let brand:String
    weak var ownedBy:Owner?
    init(brand:String){
        self.brand = brand
    }
    deinit{print("deinitialised the vehicle named \(brand)")}
}
var aryan : Owner?
var hondaCity : Vehicle?

aryan = Owner(nameowner:"Aryan Singhal")
hondaCity = Vehicle(brand:"HondaCity")

aryan!.owns = hondaCity
hondaCity!.ownedBy = aryan
aryan = nil
hondaCity = nil

//eg of unonwed

class Customer {
    let customername: String
    var customercard: CreditCard?
    init(customername: String) {
        self.customername = customername
    }
    deinit { print("\(customername) is being deinitialized") }
}


class CreditCard {
    let number: UInt64
    unowned let customername: Customer
    init(number: UInt64, customername: Customer) {
        self.number = number
        self.customername = customername
    }
    deinit { print("Card #\(number) is being deinitialized") }
}
var diksha: Customer?
diksha = Customer(customername: "Diksha Yadav")
diksha!.customercard = CreditCard(number: 1234_5678_9012_3456, customername: diksha!)
diksha = nil

//9. optionals are used to provide a initial nil value to something if no value exist for it.If exist then nil is replaced by value
//Real worl dexample --- Suppose wehave a safe and there is a key to the safe.There is a possibility that key is not there.If we want to unlock the safe then we have to make sure that there is a key.SO optionals help us to provide that if there is a key then its okay if not then no key will be shown

var numb: Int?

if let x = numb {
   print("Numb Value is \(x)!")
} else {
   print("Numb Value is unknown")
}

/*10. Error handling is a way to effectively handle code that might throw an error
4 ways to handle error are-
1. do catch block
2. Error propagation through functions
3. optional value
4. Disable error and gives run time error */

//try is used for catching the error , try? is used to convert the throwing call into an optional where you’ll get back nil if failed,try! will make app crash if throws error
/*
import Foundation

enum SimpleError: Error {
    case somethingWentWrong
}

func mightFail(succeed: Bool) throws -> String {
    if succeed {
        return "Success!"
    } else {
        throw SimpleError.somethingWentWrong
    }
}

do{
    try mightFail(succeed: true)
}catch{
    print("Error thrown: \(error)")
}
let result1 = try? mightFail(succeed: true)
let result2 = try? mightFail(succeed: false)


let result3 = try! mightFail(succeed: true)


print("try? with success: \(String(describing: result1))")
print("try? with failure: \(String(describing: result2))")
print("try! with success: \(result3)")

*/


//11. protocols are blueprint of methods that are created for particular task.
enum Week:CaseIterable{  //CaseIterbale is a built in protocol which helps us to iterate through cases in enums
    case monday,tuesday,wednesday,friday,saturday,sunday
}
let myweek = Week.allCases
for days in myweek{
    print(days)
}
