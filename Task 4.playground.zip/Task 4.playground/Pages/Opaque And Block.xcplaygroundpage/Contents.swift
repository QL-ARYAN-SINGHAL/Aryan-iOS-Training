protocol Shape{
    func draw()->String
}
struct Triangle:Shape{
    var size:Int
    func draw()->String{
        var result : [String] = []
        for length in 1..<size{
            result.append(String(repeating: "*" , count: length))
            
        }
        return result.joined(separator: "\n")
    }
}
let triangle = Triangle(size: 6)
print(triangle.draw())


struct FlippedShape<T: Shape>: Shape {
    var shape: T
    func draw() -> String {
        let lines = shape.draw().split(separator: "\n")
        return lines.reversed().joined(separator: "\n")
    }
}
let flippedTriangle = FlippedShape(shape:triangle)
print(flippedTriangle.draw())

//To join two shapes
struct JoinedShape<T:Shape , U:Shape>:Shape{
    var top : T
    var bottom : U
    func draw()->String{
        return top.draw() + "\n" + bottom.draw()
        
    }
}
let joinedtriangle = JoinedShape(top:triangle , bottom : flippedTriangle)
print(joinedtriangle.draw())


//OPAQUE TYPE

struct Square:Shape{
    var size:Int
    func draw() ->String{
        let line = String(repeating: "*", count: size)
        let result = Array<String>(repeating: line , count: size)
        return result.joined(separator:"\n")
    }
}
func makeTrapezoid()->some Shape{  //here makeTrapezoid is a opque typoe because it does not return specifically but "some" that conforms to shape protocl
    let top = Triangle(size:2)
    let middle = Square(size:2)
    let bottom = FlippedShape(shape:top)
    let trapezoid = JoinedShape(top:top , bottom: JoinedShape(top: middle, bottom:bottom))
    return trapezoid
}
let trapezoid = makeTrapezoid()
print(trapezoid.draw())

//Opaque with Generic combination
func flip<T:Shape>(_ shape : T)->some Shape{ //Here T and U are generics parameter that are combine to use with opque type some Shape
    return FlippedShape(shape: shape)
}
func join <T:Shape , U:Shape>(_ top : T , _ bottom : U)->some Shape{
    JoinedShape(top: top, bottom: bottom)
}
let opaquejoinedtriangle = join(triangle,flip(  triangle))
print(opaquejoinedtriangle.draw())

//BLOCK PROTOCOL TYPES--- THIS MEANS THAT T IS GENERIC SUCH THAT T CONFORMS TO PROTOCOL
struct VerticalShape:Shape{
    var shapes : [any Shape]
    func draw()->String{
        return shapes.map{$0.draw()}.joined(separator:"\n\n")
    }
}
let largetriangle = Triangle(size: 3 )
let largeSquare = Square(size: 5)
let vertical = VerticalShape(shapes: [largetriangle, largeSquare])
print(vertical.draw())



