import Foundation

// Simulating asynchronous fetching functions
func fetchUserData() async -> String {
    try? await Task.sleep(nanoseconds: 1_000_000_000) // Simulate delay
    return "User Data"
}

func fetchUserPosts() async -> String {
    try? await Task.sleep(nanoseconds: 1_500_000_000) // Simulate delay
    return "User Posts"
}

// Using TaskGroup to fetch both data concurrently
func fetchAllData() async {
    await withTaskGroup(of: String.self) { group in
        // Add first task
        group.addTask {
            await fetchUserData()
        }
        
        // Add second task
        group.addTask {
            await fetchUserPosts()
        }
        
        // Collect results
        var results: [String] = []
        for await result in group {
            results.append(result)
        }
        
        print("Fetched Data: \(results)")
    }
}

// Running the function
Task {
    await fetchAllData()
}


