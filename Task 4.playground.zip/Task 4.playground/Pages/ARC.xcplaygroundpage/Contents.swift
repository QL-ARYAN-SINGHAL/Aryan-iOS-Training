
//AUTOMATOIC REFERNCE COUNTING IS BASICALLY USED TO DEALLOCATE THE UNUSED MEMORY OF THE OBJECTS SO THAT RESOURCES ARE AVAILBLE FOR TOHER TO USE


//STRONG REFERENCE COUNTING: ARC KEEP A STRONG HOLD ON INSTANCE AND DOES NOT ALLOW TO BE DEALLOCATED
//EG
struct Persons{
    var name:String
}

let firstPersons = Persons(name:"Aryan") //this is strong reference and has a memory allocated for instance Person in name of firstPerson
print(firstPersons)

//STRONG REFERENCE CYCLE -- WHEN CLASSES BUILD A STRONG REFERENCE TO EACH OTHER SUCH THAT THEY KEEP BOTH OF THEM ALIVE THIS CYCLE IS CALLED SRC
class Person{
    let name:String
    init(name:String){
        self.name = name
        
    }
    var apartment : Apartment?
    deinit{print("\(name ) is bieng dinitialised")}
    
    
}
class Apartment{
    var tenant:Person?
    let unit:String
    init(unit:String){
        self.unit = unit
    }
    deinit{("\(unit) is being removed from house")}
}
var dhawal : Person?

var C126 : Apartment?

 dhawal = Person(name:"Vikram")
 C126 = Apartment(unit: "Hostel")
dhawal!.apartment=C126  //! is for force unwrap the optional
C126!.tenant=dhawal

//WEAK AND UNOWNED REFERENCECS

class Customer{
    var name:String
    var credit: CreditCard?
    init(name:String){
        self.name = name
    }
    deinit{print("\(name ) has been de initialised")}
}
class CreditCard{
    let number: UInt64  //UInt64 is a Int type that is 64 bytes
    unowned let customer:Customer   //Because CREDITCARD WILL ALWAYS HAVE CUSTOMER THAT IS WHY CUSTOMER  IS UNOWNED
    init(number:UInt64,customer:Customer){
        self.number=number
        self.customer = customer
    }
    deinit{print("Card number \(number) is deinitialised ")}
}
var john:Customer?
john = Customer(name:"John")
john!.credit = CreditCard(number: 1689, customer: john!)
john = nil


//Unowned option refernbcing
//when using unowned optional referecning it should be confirmed that they dont have nil but a proper object
class Department{
    var name:String
    var course : [Course]
    init(name:String){
        self.name=name
        self.course=[]
    }
}
class Course{
    var name:String
    unowned var department:Department?
    unowned var nextcourse:Course?
    init(name:String,in department:Department){
        self.name = name
        self.department = department
        self.nextcourse=nil
    }
}

let department = Department(name:"iOS")
let intro = Course(name: "Swift", in: department)
let advanced = Course(name: "Advanced Swift", in: department)
let intermediate = Course(name: "Intermediate Swift", in: department)
intro.nextcourse = intermediate
intermediate.nextcourse = advanced
department.course=[intro,intermediate,advanced]

//unowned references and implicitly unwrapped
class Country{
    let name:String
    var capitalCity:City!
    init(name:String , capitalCity:String){
        self.name=name
        self.capitalCity=City(name:self,country:self)
    }
    
}
class City{
    let name : String
    unowned let country:Country
    init(name:String , country:Country){
        self.name=name
        self.country=country
    }
    
}
var country = Country(name: "Canada", capitalName: "Ottawa")
print("\(country.name)'s capital city is called \(country.capitalCity.name)")
