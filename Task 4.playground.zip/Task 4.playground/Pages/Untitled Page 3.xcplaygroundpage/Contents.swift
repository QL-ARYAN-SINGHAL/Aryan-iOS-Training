import Foundation
func fetchuser() async->String{
    try? await Task.sleep(nanoseconds: 100000000)
    return "User Data"
}

func fetchPost () async ->String{
    try? await Task.sleep(nanoseconds: 100000000)
    return "Post Data"
}

func fetchAllData() async{
    await withTaskGroup(of: String.self){
        group in
        group.addTask{await  fetchuser()}
        group.addTask{await  fetchAllData()}
    }
    var result:[String] = []
    for await result in group{
        results.append(result)
        
    }
    print("Fetched result \(results)")
}
Task {
    await fetchAllData()
}
