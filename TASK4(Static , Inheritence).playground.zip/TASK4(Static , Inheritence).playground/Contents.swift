let names=["Aryan" , "Dhawal " , "Diksha","Akash","Ar","Aryansinghal" , "Bhanu" ]
func backward(_ str1:String , _ str2:String)->Bool{
    return str1>str2
}
var newnames = names.sorted(by: backward)
print(newnames)


var inlineReversedBy = names.sorted(by:{(s1:String,s2:String)->Bool in return s1>s2})  //INLINE CLOSURE
print(inlineReversedBy)

var inferringReversedBy = names.sorted(by:{s1,s2 in return s1>s2}) //INFERRING TYPE CLOSURE WHERE SWIFT AUTO.                                                                        INFERS THE RETURN TYPE AND ARGUMENT TYPE
print(inferringReversedBy)

var implicitReversedBy = names.sorted(by: {s1,s2 in s1>s2}) //IMPLICIT RETURNS WHERE THERE IS NO NEED TO WRITE                                                                 RETURN KEYWORD
print(implicitReversedBy)

var shorthandReversedBy = names.sorted(by:{$0>$1}) //Shorthand arguments where argument types are replaceed by                                         $0,1,2.. and no need to write IN keyword also ,we can directly write the body
print(shorthandReversedBy)

var operatorReversedBy = names.sorted(by: >)
print(operatorReversedBy)


let digitNames = [
    0: "Zero", 1: "One", 2: "Two",   3: "Three", 4: "Four",
    5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
]
let numbers = [16, 58, 510]

//TRAILING CLOSURES

let strings = numbers.map{(number) -> String in //map is also a trailing closure type
    var number=number
    var output = ""
    repeat{
        output = digitNames[number%10]! + output  //here ! is force wrap means that value cant be nil
        number /= 10
        
    }
    while number > 0
            return output
}
print(strings)


//CAPTURING VALUES
func makeIncrement(forIncrement amount:Int)->()->Int{
    var runningtotal=0
    func incrementer()->Int{   //()---No need of having parameter because it takes reference from surrounding function(makeIncrement)
       runningtotal+=amount
        return runningtotal
    }
    return incrementer
}
let firstincrementvalue = makeIncrement(forIncrement: 10)
print(
    firstincrementvalue()   //firstincrementvalue has reference of nested func named incrementer()
)

let secondvalue = makeIncrement(forIncrement: 5)  //NOTE- each new variable caliing th function ,they all are refernce types so they wont affect each other and original value
print(secondvalue())


print(
    firstincrementvalue()
)


//AUTIOCLOSURE PROPERTY
var customersInLine = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]
print(customersInLine.count)



let customerProvider = { customersInLine.remove(at: 0) }
print(customersInLine.count)
// Prints "5"


print("Now serving \(customerProvider())!")
// Prints "Now serving Chris!"
print(customersInLine.count)
// Prints "4"

let newcustomer = {customersInLine.remove(at:3)}
print("my new customer name is \(newcustomer())")
print(customersInLine.count)
