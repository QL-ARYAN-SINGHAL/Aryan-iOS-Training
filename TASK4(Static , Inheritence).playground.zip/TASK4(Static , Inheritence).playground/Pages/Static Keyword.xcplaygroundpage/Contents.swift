class Counter {
    var count = 0
    func increment() {
       return count += 1
    }
    func increment(by amount: Int) {
        count += amount
    }
    func reset() {
        count = 0
    }
}
let counter = Counter()

counter.increment()
print(counter.count)

counter.increment(by: 5)
print(counter.count)

counter.reset()
print(counter.count)




//Enum case for mutating self

enum TriStateSwitch{
    case off,low,high
    mutating func next(){
        switch self{
        case .off: self = .low
        case .low : self = .high
        case .high : self = .off
        }
    }
        
    }
var ovenLight = TriStateSwitch.low
ovenLight.next()
print(ovenLight)
ovenLight.next()
print(ovenLight)
ovenLight.next()
print(ovenLight)
var RefrigeratorLight = TriStateSwitch.high
RefrigeratorLight.next()
print(RefrigeratorLight)

class Animal{
    static func speak(){
        print("Hi i am animal")  //STATIC KEYOWRD IS MADE FOR ACCESSING THROUGH TYPE ITSELF
    }
}
Animal.speak()

//EXAMPLE OF STTAIC KEYWORD

struct Leveltracker{
    static var highestLevelUnlocked = 1
    var currLevel = 1
    
    static func unlock(_ level : Int){
        if highestLevelUnlocked<level {
            highestLevelUnlocked=level
        }
    }
    static func isLevelUnlocked(_ level :Int )->Bool{
        return level<=highestLevelUnlocked
    }
    mutating func advance(to level:Int)->Bool{
        if Leveltracker.isLevelUnlocked(level){
            currLevel=level
            return true
            
        }
        else{
            return false
        }
    }}
    class Player {
        var tracker = Leveltracker()
        let playerName: String
        func complete(level: Int) {
            Leveltracker.unlock(level + 1)
            tracker.advance(to: level + 1)
        }
        init(playerName: String) {
            self.playerName = playerName
        }
    }
    var player = Player(playerName: "Lucifer 2684")
    player.complete(level: 1)
print("hi i am \(player.playerName) and the highest unlocked level is now \(Leveltracker.highestLevelUnlocked)")
   

    


