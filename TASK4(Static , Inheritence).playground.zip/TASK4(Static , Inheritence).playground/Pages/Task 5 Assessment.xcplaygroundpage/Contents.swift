/* 1.  Swift is a powerful and easy to learn language used to create applications in the world of iOS. It is significant in world of app development because of mainly 3 reasons:
a) Short and easy to write syntax
b) Modern features
c) Memory efficient

2.                SWIFT                                  OBJECTIVE C
   A) Swift offers concise and readable syntax       a) Objective c is more of complex and verbose syntax
   B) Swift language is very much maintainable       b) Objective C is twice hard to maintain
   C) the length of code developer has to write      c) The length of code in Objective c is more as compared with swift
   for execution of task is less
   D) Swift as enhanced security system              d) Objective C have outdated security system

3. Variable in swift are containers which are mutable, which measn values inside them can change
   */
    var x = 32
    print(x)
    x=58
    print(x)
print("\n")
    //Constants are containers which are immutable, which means the value inside them cannot change
    let y = 14
    print(y)
  //  y=1     This shows error
    print(y)
    print("\n")
//4. In arrays we declare them simply by naming the array and keeping it inside a containers as per the task, like :
    var a = [1,2,3,4]
    a.append(5)
    print(a)

    //In dictionary we declare them by providing a key and value .like:
    var b = ["Aryan" : 21 , "Saurav" : 27]
    b["Aryan"] = 22
    print(b)

//5. optional in swift is a way through which we provide a value of something as nil.They help us to avoid run time error due to missing value.
//To unwrap optional safely 2 ways are :
  //  1 . use of if-let

    var name : String? = "Aryan"
    if let myname = name{
        print("my name is \(myname)")
    }
    else{
        print("Value is nill")
    }

 // 2. use of nill coalescing


var username = name ?? "Saurav"
 print(username)

 //6. Swift supports strict data typing to prevent errors and improve performance.
//Type inference allows Swift to determine variable types automatically as per the value provided by the user

//7. Conditional statement in swift are control flows to flow inside the code and to check the task asa per the condition provided
 var Animal = "Bird"
 if Animal == "Bird"{
    print("yes it is a bird")
 }

 var animal = "Dog"
 if animal == "Cat"{
    print("Cat is a animal")
 }
 else if animal == "Dog" {
print("Dog is a animal")
 }

 var Mammal = "Whale"
 switch Mammal{
    case "Shark":print("its a shark")
    case "Whale" : print("Its a whale ")
    default: print("Are your sure its a mammal")
 }

 //8. In swift we create a function by providing a function name,arguments it will take and type of value it will return eg,
  func age(_ a:Int , _ b :Int)->Int{    //Creating a function
    if a>b{
        return a
    }
    return b
  }
  let myage = age(21,20)    //Function call
  print(myage)

//9. Loops in swift are used to iterate over an array or any collection
//for in loop-- they iterate over the collection
    var apple = ["iphone 12" ,"Iphone 13" , "Iphone 14"]
    for phone in apple{
        print(phone)
    }


// while loops are loops which run until the condition becomes false
  var num = 1
  while num<7{
    print(num)
    num+=1
  }

//10.  OOPS stands for object oritented programming. It is basically used to make our code more managable,readable,flexible.It is bluepirnt that we create for any instance,it consist of 4 pillars - Polymorphism,inheritence,encapsulation and abstraction
class Animals{
    var name: String
    init(name:String){
        self.name=name
    }
}
var animalType = Animals(name: "Dog")
print("type of animal i have is caled as a \(animalType.name)")


class Bird{
    var name = "mithoo"
    
    func speak(){
        print("Voices of brds")
    }
}
class Parot:Bird{
    override func speak(){
        print("i speak koo koo")
    }
}
let mybird = Bird()
print(mybird.name)

let anotherbird = Parot()
print(anotherbird.name)

//There are 4 ways to handle errors in Swift. You can Propagating Errors Using Throwing Functions, handle the error using a try - catch statement, handle the error as an optional value, or assert that the error will not occur.
//try catch mechanism in swift is used to hadnle the error . Fucntion or variable goes inside the try block if failed then caught in catch block and throws error
