
class Vehicle {
    var currentSpeed: Double = 0.0
    
    var description: String {
        return "Traveling at \(currentSpeed) km/h"
    }
    
    func nameVehicle() {
        print("Some generic vehicle name")
    }
}

class Car: Vehicle {
    var gear: Int = 1
    
  
    override var description: String {
        return "Car is in gear \(gear) and moving at \(currentSpeed) km/h"
    }
    
    
    override func nameVehicle() {
        print("Car name: Honda City")
    }
}


 class SportsCar: Car {
    var turboBoost: Bool = false
    
    
    override var description: String {
        return "SportsCar in gear \(gear), speed \(currentSpeed) km/h, Turbo Boost: \(turboBoost)"
    }
    
    
    override func nameVehicle() {
        print("SportsCar name: Porsche 911 turbo")
    }
}
class MotorBoat:Car{
    var color:String = ""
    override var description:String{
        return "MotorBoat in gear \(gear) , speed is \(currentSpeed) and color of Boat is \(color)"
    }
    override func nameVehicle(){
        print("Name of my vehicle is : RDX 350")
    }
}
class SuperCar:SportsCar{
    
    override var description: String {
        return "SuperCar in gear \(gear),  Turbo Boost: \(turboBoost)"
    }
    
    
    override func nameVehicle() {
        print("SuperCar name: Rolls Royce Ghost")
    }
}


let myCar = Car()
myCar.currentSpeed = 60.0
myCar.gear = 3
print(myCar.description)
myCar.nameVehicle()
print()
let mySportsCar = SportsCar()
mySportsCar.currentSpeed = 120.0
mySportsCar.gear = 5
mySportsCar.turboBoost = true
print(mySportsCar.description)
mySportsCar.nameVehicle()
print()
let myBoat = MotorBoat()
myBoat.color="red"
myBoat.gear = 2
myBoat.currentSpeed=50
print(myBoat.description)
myBoat.nameVehicle()
print()
let mySuperCar = SuperCar()
mySuperCar.currentSpeed = 220.0
mySuperCar.gear = 6

print(mySuperCar.description)
mySuperCar.nameVehicle()
