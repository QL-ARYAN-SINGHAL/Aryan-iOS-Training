class MediaItem{
    var name:String
    init(name:String){
        self.name = name
    }
}
class Movie : MediaItem{
    var director:String
    init(name:String, director :String){
        self.director = director
        super.init(name:name)
    }
}
class Song:MediaItem{
    var artist:String
    init(name:String , artist:String){
        self.artist = artist
        super.init(name:name)
    }
}
class Roleplay{
    var newname:String
    var producer:String
    init(newname:String , producer:String){
        self.newname = newname
        self.producer=producer
        
        
    }
}
let library = [
    Movie(name:"Krish" , director:"Dhawal Bisht"),
    Movie(name:"Golmaal" , director :"Vikram"),
    Song(name:"ae dil hai mushkilllll" , artist : "Babbu Maan"),
    Song(name: "Jaadu jaadu" , artist:"Dhawal"),
    Song(name: "Wishes" , artist :"Talwinder"),
   
]
var moviecount=0
var songcount = 0
for item in library{
    if item is Movie{
        moviecount+=1
        print("Moive increase by 1 ")
    }
    else if item is Song{
        songcount+=1
        print("Song count increased by 1 ")
    }
    
}
print("Movie count is \(moviecount) and song count is \(songcount)")

for items in library{
    if let movie = items as? Movie{   //since we are not sure that in library the elemensts are of Moive or Song or any other so we use "as?" downcast to access the description of them if false then return nil. is we have use the "as!" then it would mean that this should be successfull not an option
        print("movie name is \(movie.name) and director is \(movie.director)" )
    }else if let song = items as? Song{
        print("Songs name is \(song.name    ) and artist is \(song.artist)")
        
    }}

//TYPECASTING FOR ANY AND ANYOBJ
var things : [Any] = []
things.append(0)
things.append(0.0)
things.append(42)
things.append(3.14159)
things.append("hello")
things.append((3.0, 5.0))
things.append(Movie(name: "Ghostbusters", director: "Ivan Reitman"))
things.append({ (name: String) -> String in "Hello, \(name)" })    //it is a closure not a function remember the syntax ({parameters})->return type in <statement>

for thing in things {
    switch thing {
    case 0 as Int:
        print("zero as an Int")
    case 0 as Double:
        print("zero as a Double")
    case let someInt as Int:
        print("an integer value of \(someInt)")
    case let someDouble as Double where someDouble > 0:
        print("a positive double value of \(someDouble)")
    case is Double:
        print("some other double value that I don't want to print")
    case let someString as String:
        print("a string value of \"\(someString)\"")
    case let (x, y) as (Double, Double):
        print("an (x, y) point at \(x), \(y)")
    case let movie as Movie:
        print("a movie called \(movie.name), dir. \(movie.director)")
    case let stringConverter as (String) -> String:
        print(stringConverter("Michael"))
    default:
        print("something else")
    }
}
