
struct BlackJackCard{
    
    //nested enum of structure
    enum Suit:Character{
        case spades = "♠️"
        case hearts = "❤️"
        case diamonds = "♦️"
        case clubs = "♣️"
    }
    //nested enum of structure
    enum Rank:Int{
        case two = 2,three,four,five,six,seven,eight,nine,ten
        case jack,king,queen,ace
        
        //nested structure of enum
        struct Values{
            let first:Int
            let second:Int?
        }
        //properties of ENUM
        var values : Values{
            switch self{
            case .jack,.queen,.king:return Values(first:10 , second:nil)
            case .ace:return Values(first:1,second:11)
            default: return Values(first:self.rawValue,second:nil)
            }
        }
        
        
    }
    //properties of main structure
    let rank:Rank , suit:Suit
    var description : String{
        var output =  "Suit has raw value \(suit.rawValue)"
        output += "Rank of value is \(rank.values.first)"
        if let second = rank.values.second{       //since the "second" property is a optional type so in this line we are safe unwraping the optionals using if let
            output += " or \(second)"
        }
        return output
    }
}
let theAceOfSpade = BlackJackCard(rank:.ace , suit : .clubs)
print("Ace os spade :\(theAceOfSpade.description)")

//to access nested type directl;y outside the context
let heartshaped = BlackJackCard.Suit.spades.rawValue
print(heartshaped)

let DiamonQueen = BlackJackCard(rank:.queen , suit: .diamonds)
print(DiamonQueen.description)
