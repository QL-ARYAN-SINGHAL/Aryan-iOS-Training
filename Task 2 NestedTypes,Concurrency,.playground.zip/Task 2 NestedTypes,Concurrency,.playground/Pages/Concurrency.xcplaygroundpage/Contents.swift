/* import Foundation

func listPhotos(inGallery name:String) async ->[String]{
    let result = [ "Hi o am aryan" , "Singhal"]
    return result
}
let photoNames = await listPhotos(inGallery: "Summer Vacation")
let sortedNames = photoNames.sorted()
let name = sortedNames[0]
//let photo = await downloadPhoto(named: name)
//show(photo)

func listphotos(inGallery name:String) async throws -> [String] {
    try await Task.sleep(for: .seconds(5))
    return ["Aryan" , "Singhal"]
}

let handle = FileHandle.standardInput
for try await line in handle.bytes.lines {
    print(line)
}*/
/*
let firstPhoto = await downloadPhoto(named: photoNames[0])
let secondPhoto = await downloadPhoto(named: photoNames[1])
let thirdPhoto = await downloadPhoto(named: photoNames[2])


let photos = [firstPhoto, secondPhoto, thirdPhoto]
show(photos)
async let firstPhoto = downloadPhoto(named: photoNames[0])
async let secondPhoto = downloadPhoto(named: photoNames[1])
async let thirdPhoto = downloadPhoto(named: photoNames[2])


let photos = await [firstPhoto, secondPhoto, thirdPhoto]
show(photos) */



//Actors - They help in sharing the information among task as task themselves cannot

actor TemperatureLodging{
    let label:String
    var measurements:[Int]
    private(set) var max :Int
    init(label:String,measurement:Int){
        self.label = label
        self.measurements = [measurement]
        self.max = measurement
    }
}
let lodger = TemperatureLodging(label:"My lodge" , measurement: 24)
print(await lodger.max)

extension TemperatureLodging{
    func update(with measurement:Int){
        measurements.append(measurement)
        if measurement>max{
            max = measurement
        }
        }
    
}
extension TemperatureLodging{
    func ToFarenheit(){
        measurements = measurements.map{measurement in (measurement*9/5)+32
        }
    }
}
